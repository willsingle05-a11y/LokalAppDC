﻿const icons = {
  compass: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="9"/><path d="m15.4 8.6-2.1 4.7-4.7 2.1 2.1-4.7 4.7-2.1Z"/></svg>',
  map: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="m9 18-6 3V6l6-3 6 3 6-3v15l-6 3-6-3Z"/><path d="M9 3v15M15 6v15"/></svg>',
  spark: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="m12 2 1.8 6.2L20 10l-6.2 1.8L12 18l-1.8-6.2L4 10l6.2-1.8L12 2Z"/><path d="m19 17 .7 2.3L22 20l-2.3.7L19 23l-.7-2.3L16 20l2.3-.7L19 17Z"/></svg>',
  people: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M16 20v-1a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v1"/><circle cx="9" cy="7" r="4"/><path d="M22 20v-1a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8"/></svg>',
  bell: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/></svg>',
  user: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></svg>'
};

const demoEvents = [
  { id: 1, title: "Jazz on the Hill", venue: "Songbyrd Music House", area: "Adams Morgan", time: "Tonight, 7:30 PM", price: "$18", cat: "music", tag: "Live music", friends: ["AL"], desc: "A warm, unhurried set from DC's new guard of jazz players. The room is small, the sound is close, and you will want to get there before the first pour." },
  { id: 2, title: "After Hours: New Forms", venue: "Transformer Gallery", area: "Logan Circle", time: "Tonight, 6:00 PM", price: "Free", cat: "art", tag: "Art opening", friends: [], desc: "A compact group show of vivid mixed-media work, with the artists in the room and a neighborhood wine bar waiting around the corner." },
  { id: 3, title: "Sunset Miles", venue: "Meridian Hill Park", area: "U Street", time: "Tonight, 6:30 PM", price: "Free", cat: "fitness", tag: "Run club", friends: ["MR", "DV"], desc: "A friendly four-mile loop with no pace pressure. Stay after for the picnic blanket hang and a rotating neighborhood snack stop." },
  { id: 4, title: "Skyline Social", venue: "The Viceroy Rooftop", area: "Logan Circle", time: "Friday, 8:00 PM", price: "$15", cat: "nightlife", tag: "Rooftop", friends: ["AL", "MR", "JS"], desc: "Golden hour turns into a low-key rooftop party with disco edits, a sharp little drinks menu, and just enough room to actually talk. A reliable Friday reset." },
  { id: 5, title: "Little Food Market", venue: "The Roost Courtyard", area: "Shaw", time: "Saturday, 12:00 PM", price: "Free", cat: "food", tag: "Food pop-up", friends: ["DV"], desc: "Six DC makers, one sunny courtyard, and an excellent excuse to order something you have never tried before." },
  { id: 6, title: "No Kings: Vinyl Night", venue: "The Crown & Crow", area: "Logan Circle", time: "Saturday, 9:00 PM", price: "$10", cat: "nightlife", tag: "DJ set", friends: [], desc: "A deep crate evening with soul, funk, and house selections in a room that always feels a little hidden." },
  { id: 7, title: "Porchlight Sessions", venue: "The Atlantis", area: "U Street", time: "Sunday, 7:00 PM", price: "$22", cat: "music", tag: "Live music", friends: ["JS"], desc: "Three local songwriters trade songs and stories in an intimate Sunday night round." },
  { id: 8, title: "Fresh Air Cinema", venue: "Alethia Tanner Park", area: "Shaw", time: "Sunday, 8:15 PM", price: "Free", cat: "art", tag: "Outdoor film", friends: ["AL", "DV"], desc: "Bring a blanket and settle in for a neighborhood screening under the string lights." },
  { id: 9, title: "Portrait Gallery After Five", venue: "Smithsonian American Art Museum", area: "Penn Quarter", time: "Friday, 5:30 PM", price: "Free", cat: "art", tag: "Museum night", friends: ["JS"], desc: "A relaxed early evening at the museum with a gallery talk, a small bar, and enough time to wander before dinner." },
  { id: 10, title: "Atlas Local Stage", venue: "Atlas Performing Arts Center", area: "H Street", time: "Saturday, 7:00 PM", price: "$20", cat: "music", tag: "Local showcase", friends: ["MR"], desc: "A three-act local showcase in a neighborhood theater that makes a good anchor for a Saturday on H Street." },
  { id: 11, title: "Songbyrd Patio Set", venue: "Songbyrd Music House", area: "Adams Morgan", time: "Saturday, 4:00 PM", price: "Free", cat: "music", tag: "Patio set", friends: ["AL", "DV"], desc: "An easy afternoon patio set with a short local lineup and room to stop by without making the whole day revolve around it." }
];
let events = [...demoEvents];
const friendNames = { AL: "Ana", MR: "Marcus", DV: "Dev", JS: "Jules", PL: "Priya", ET: "Elena", NW: "Nia", CB: "Chris" };
const savedProfile = JSON.parse(localStorage.getItem("lokalProfile") || "null");
const tasteOptions = ["Live music", "Food", "Art", "Patios", "Sports", "Run clubs", "Comedy", "Rooftops", "Museums", "Markets", "Outdoor movies", "Theater", "Coffee", "Dancing", "Trivia", "Book clubs", "Wellness", "Volunteering", "Pop-ups", "Free events", "Low-key hangs", "New in town", "Wine bars", "Cocktail bars", "Jazz", "DJs", "Karaoke", "Festivals", "Street fairs", "Farmers markets", "Classes", "Networking", "Dating-friendly", "Family-friendly", "Dog-friendly", "Brunch", "Late night food", "Speakeasies", "Gallery openings", "History", "Parks", "Pickleball", "Yoga", "Board games", "LGBTQ+ events", "College events", "Professional mixers"];
const defaultReceipts = [
  { id: "receipt-songbyrd", title: "Flashband at Songbyrd", time: "May 24, 8:00 PM", venue: "Songbyrd Music House", price: "$18", cat: "concerts", desc: "A saved memory from a local show. Receipts will work the same way for future events once you mark that you went.", friends: ["AL", "DV"], attendedAt: new Date("2026-05-24T20:00:00").getTime() },
  { id: "receipt-open-streets", title: "Open Streets DC", time: "May 18, 12:00 PM", venue: "Shaw", price: "Free", cat: "community", desc: "A community receipt showing who you went with and how it contributes to your Lokal score.", friends: ["MR"], attendedAt: new Date("2026-05-18T12:00:00").getTime() },
  { id: "receipt-hirshhorn", title: "After Dark at the Hirshhorn", time: "May 9, 7:00 PM", venue: "Hirshhorn Museum", price: "$20", cat: "performing-arts", desc: "Receipts can reopen the event memory later, including friends and category.", friends: ["JS", "AL"], attendedAt: new Date("2026-05-09T19:00:00").getTime() }
];
const state = { route: "home", socialTab: "saved", plannerWeekOffset: 0, homeFilter: "all", mapFilter: "all", mapZoom: 1, mapSearch: "", mapCenter: { x: 50, y: 50 }, age: savedProfile?.age || 27, bio: savedProfile?.bio || "Always looking for a good live show, a new restaurant, and an excuse to get outside.", tastes: savedProfile?.tastes || ["Live music", "Food", "Art", "Patios"], profile: savedProfile || { fullName: "Jordan Miller", username: "jordanindc", phone: "(202) 555-0148", birthdate: "", age: 27, initials: "JM", tastes: ["Live music", "Food", "Art", "Patios"], privateAccount: false }, privateAccount: Boolean(savedProfile?.privateAccount), filter: {}, highlightedOnly: false, eventSync: { status: "loading", label: "Checking shared events..." }, pendingSignupPhone: "", pendingSignupProfile: null, joinedGroups: new Set(), pinnedGroups: new Set(["Friday crew"]), leftGroups: new Set(), hype: new Set(), follows: new Set(["songbyrd"]), friends: new Set(["Ana Lopez", "Marcus Reed", "Jules Kim", "Dev Shah", "Elena Torres"]), saved: new Set(), rsvps: new Set(), attended: new Set(JSON.parse(localStorage.getItem("lokalAttended") || "[]")), receipts: JSON.parse(localStorage.getItem("lokalReceipts") || JSON.stringify(defaultReceipts)), storyPosts: JSON.parse(localStorage.getItem("lokalStoryPosts") || "[]"), newGroups: [], groupType: "private", onboardStep: 0, selections: new Set(), showAllGroups: false, groupMessages: {}, privateGroupMembers: { "Friday crew": ["You","Ana Lopez","Marcus Reed","Dev Shah","Jules Kim","Priya Lee"], "Culture club": ["You","Priya Lee","Jules Kim","Ana Lopez","Elena Torres"], "Capitol picnic crew": ["You","Marcus Reed","Nia Williams","Chris Bennett"], "Gallery hopping": ["You","Dev Shah","Priya Lee","Elena Torres"], "Sunday coffee walk": ["You","Ana Lopez","Sofia Kim","Nia Williams"] }, directMessages: { "Ana Lopez": [{ from: "Ana", text: "Want to check out the Songbyrd show this week?" }], "Marcus Reed": [{ from: "Marcus", text: "I sent the run club details. It looks relaxed." }] }, pendingRequests: [{ id: "friend-priya", type: "friend", name: "Priya Lee", from: "Priya", detail: "You have 4 mutual friends.", time: "25 minutes ago" }] };
const app = document.querySelector("#app");
const modalRoot = document.querySelector("#modal-root");
state.friendConnections = { [state.profile.fullName]: Array.from(state.friends) };

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, character => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[character]));
}

function avatarStack(friends) {
  if (!friends.length) return "";
  return `<span class="avatars">${friends.map(f => `<span class="avatar">${f}</span>`).join("")}</span>`;
}

function interestedFriendsForEvent(event) {
  const knownFriends = ["AL", "MR", "DV", "JS", "PL", "ET", "NW", "CB"];
  const explicit = (Array.isArray(event.friends) ? event.friends : []).filter(friend => friendNames[friend]);
  const seed = Array.from(String(event.sourceId || event.id || event.title || "lokal")).reduce((sum, character) => sum + character.charCodeAt(0), 0);
  const suggested = [knownFriends[seed % knownFriends.length], knownFriends[(seed + 3) % knownFriends.length]];
  return [...explicit, ...suggested].filter((friend, index, all) => friend && all.indexOf(friend) === index).slice(0, 2);
}

function eventInterestSignal(event, detail = false) {
  const friends = interestedFriendsForEvent(event);
  if (!friends.length) return "";
  const names = friends.map(friend => friendNames[friend]);
  const wording = names.length === 1 ? `${names[0]} is interested` : `${names[0]} and ${names[1]} are interested`;
  return `<div class="${detail ? "attendee-line" : "signal"}">${avatarStack(friends)} ${wording}</div>`;
}

function eventVisualCategory(event) {
  const map = { concerts: "music", "performing-arts": "art", museums: "art", festivals: "food", sports: "fitness", expos: "art", community: "food", nightlife: "nightlife" };
  return map[event.cat] || event.cat;
}

function eventArtKind(event) {
  const tags = eventTags(event).join(" ").toLowerCase();
  const titleText = `${event.title || ""} ${event.venue || ""} ${event.cat || ""} ${tags}`.toLowerCase();
  let key = event.cat || "community";
  if (/museum|smithsonian|hirshhorn|renwick|portrait gallery|american art museum|air and space|natural history|american history/.test(titleText)) return "museum";
  if (/run club|running|run\b|5k|10k|marathon|jog/.test(titleText)) return "run";
  if (/baseball|mlb|nationals|nats\b/.test(titleText)) return "baseball";
  if (/basketball|nba|wnba|wizards|mystics/.test(titleText)) return "basketball";
  if (/soccer|mls|nwsl|d\.?c\.? united|dc united|washington spirit/.test(titleText)) return "soccer";
  if (/hockey|nhl|capitals|caps\b/.test(titleText)) return "hockey";
  if (/football|nfl|commanders/.test(titleText)) return "football";
  if (/comedy|stand-up|standup/.test(titleText)) key = "comedy";
  if (/film|cinema|movie|screening/.test(titleText)) key = "film";
  if (/gallery|art|exhibit|exhibition/.test(titleText)) key = "arts";
  if (/yoga|fitness|wellness|pickleball/.test(titleText)) key = "fitness";
  if (/nightlife|nightclub|club|bar|lounge|rooftop|cocktail|dance party|after dark|late night|dj set/.test(titleText)) key = "nightlife";
  if (/food|market|chef|brunch|wine|beer|cocktail|restaurant/.test(titleText)) key = "food";
  return key;
}

function genericEventArt(event) {
  const key = eventArtKind(event);
  const art = {
    concerts: { a: "#42d87c", b: "#18c76f", c: "#d9ffe8", shapes: "<path d='M18 72 C34 42 66 42 82 72' fill='none' stroke='white' stroke-width='5'/><path d='M34 44 V22 L64 31 V55' fill='none' stroke='white' stroke-width='5'/><circle cx='34' cy='67' r='9' fill='rgba(255,255,255,.85)'/><circle cx='64' cy='67' r='9' fill='rgba(255,255,255,.65)'/>" },
    "performing-arts": { a: "#3fd47b", b: "#0bbf73", c: "#cdf9db", shapes: "<path d='M18 24 Q50 11 82 24 V82 Q50 67 18 82 Z' fill='rgba(255,255,255,.2)' stroke='white' stroke-width='4'/><path d='M33 43 Q50 54 67 43' fill='none' stroke='white' stroke-width='5'/><circle cx='37' cy='34' r='4' fill='white'/><circle cx='63' cy='34' r='4' fill='white'/>" },
    sports: { a: "#4ce083", b: "#12c77a", c: "#e5ffef", shapes: "<rect x='16' y='22' width='68' height='56' rx='12' fill='rgba(255,255,255,.15)' stroke='white' stroke-width='4'/><path d='M16 50 H84 M50 22 V78' stroke='white' stroke-width='4'/><circle cx='50' cy='50' r='13' fill='none' stroke='white' stroke-width='4'/>" },
    festivals: { a: "#36d676", b: "#00c897", c: "#d8ffe9", shapes: "<path d='M18 42 C33 23 67 23 82 42' fill='none' stroke='white' stroke-width='5'/><path d='M26 46 H74 L68 78 H32 Z' fill='rgba(255,255,255,.22)' stroke='white' stroke-width='4'/><path d='M36 46 V78 M50 35 V78 M64 46 V78' stroke='white' stroke-width='4'/>" },
    community: { a: "#5fe18d", b: "#28cf79", c: "#e7fff0", shapes: "<path d='M22 80 V38 H47 V80 M53 80 V24 H78 V80' fill='rgba(255,255,255,.55)' stroke='white' stroke-width='4'/><path d='M30 48 H39 M61 36 H70 M61 50 H70' stroke='white' stroke-width='4'/><circle cx='28' cy='23' r='8' fill='rgba(255,255,255,.75)'/>" },
    expos: { a: "#46dc82", b: "#10c578", c: "#dfffea", shapes: "<rect x='19' y='25' width='62' height='52' rx='7' fill='rgba(255,255,255,.35)' stroke='white' stroke-width='4'/><path d='M29 39 H71 M29 52 H71 M29 65 H56' stroke='white' stroke-width='4'/><circle cx='74' cy='22' r='8' fill='rgba(255,255,255,.65)'/>" },
    food: { a: "#50dc82", b: "#18c973", c: "#eafff1", shapes: "<path d='M30 22 V57 M40 22 V57 M30 40 H40 M60 22 V78' stroke='white' stroke-width='5' stroke-linecap='round'/><path d='M22 70 C34 54 66 54 78 70' fill='rgba(255,255,255,.35)' stroke='white' stroke-width='4'/><circle cx='50' cy='48' r='10' fill='rgba(255,255,255,.45)'/>" },
    film: { a: "#35d374", b: "#0fc983", c: "#d8ffe8", shapes: "<rect x='19' y='28' width='62' height='44' rx='7' fill='rgba(255,255,255,.2)' stroke='white' stroke-width='4'/><path d='M37 39 L37 61 L59 50 Z' fill='white'/><path d='M24 35 H30 M24 47 H30 M24 59 H30 M70 35 H76 M70 47 H76 M70 59 H76' stroke='white' stroke-width='3'/>" },
    museum: { a: "#58e28a", b: "#1acb75", c: "#e6fff0", shapes: "<path d='M18 78 H82' stroke='white' stroke-width='5'/><path d='M24 35 H76 L50 19 Z' fill='rgba(255,255,255,.32)' stroke='white' stroke-width='4'/><path d='M29 35 V72 M43 35 V72 M57 35 V72 M71 35 V72' stroke='white' stroke-width='5'/><path d='M23 72 H77' stroke='white' stroke-width='5'/>" },
    arts: { a: "#58e28a", b: "#1acb75", c: "#e6fff0", shapes: "<rect x='23' y='20' width='54' height='62' rx='8' fill='rgba(255,255,255,.35)' stroke='white' stroke-width='4'/><circle cx='42' cy='43' r='10' fill='rgba(255,255,255,.6)'/><path d='M30 69 C42 54 53 61 69 42' fill='none' stroke='white' stroke-width='5'/>" },
    comedy: { a: "#45dc80", b: "#0bc479", c: "#e3ffed", shapes: "<path d='M25 28 Q50 18 75 28 L70 72 Q50 84 30 72 Z' fill='rgba(255,255,255,.22)' stroke='white' stroke-width='4'/><circle cx='40' cy='43' r='4' fill='white'/><circle cx='60' cy='43' r='4' fill='white'/><path d='M37 58 Q50 68 63 58' fill='none' stroke='white' stroke-width='5'/>" },
    run: { a: "#61e591", b: "#18c879", c: "#e9fff2", shapes: "<path d='M24 68 C34 77 55 78 77 66 C81 64 80 57 75 56 L58 52 L45 37 L36 42 L46 58 L31 57 C24 56 20 63 24 68 Z' fill='rgba(255,255,255,.42)' stroke='white' stroke-width='4' stroke-linejoin='round'/><path d='M31 70 C42 74 58 74 75 66 M45 58 L58 52' stroke='white' stroke-width='4' fill='none'/><circle cx='38' cy='33' r='7' fill='rgba(255,255,255,.72)'/>" },
    baseball: { a: "#4ce083", b: "#12c77a", c: "#e5ffef", shapes: "<circle cx='50' cy='50' r='31' fill='rgba(255,255,255,.24)' stroke='white' stroke-width='5'/><path d='M33 26 C41 38 41 62 33 74 M67 26 C59 38 59 62 67 74' fill='none' stroke='white' stroke-width='4'/><path d='M36 37 L41 34 M36 47 L42 45 M36 57 L42 60 M64 37 L59 34 M64 47 L58 45 M64 57 L58 60' stroke='white' stroke-width='3'/>" },
    basketball: { a: "#4ce083", b: "#12c77a", c: "#e5ffef", shapes: "<circle cx='50' cy='50' r='31' fill='rgba(255,255,255,.18)' stroke='white' stroke-width='5'/><path d='M20 50 H80 M50 19 V81 M29 29 C43 41 43 59 29 71 M71 29 C57 41 57 59 71 71' fill='none' stroke='white' stroke-width='4'/>" },
    soccer: { a: "#4ce083", b: "#12c77a", c: "#e5ffef", shapes: "<circle cx='50' cy='50' r='31' fill='rgba(255,255,255,.18)' stroke='white' stroke-width='5'/><path d='M50 34 L64 44 L59 61 H41 L36 44 Z' fill='rgba(255,255,255,.45)' stroke='white' stroke-width='4'/><path d='M50 34 V22 M64 44 L78 39 M59 61 L66 75 M41 61 L34 75 M36 44 L22 39' stroke='white' stroke-width='4'/>" },
    hockey: { a: "#4ce083", b: "#12c77a", c: "#e5ffef", shapes: "<path d='M34 21 L51 68' stroke='white' stroke-width='6' stroke-linecap='round'/><path d='M66 21 L52 68' stroke='white' stroke-width='6' stroke-linecap='round'/><path d='M42 70 H71' stroke='white' stroke-width='6' stroke-linecap='round'/><ellipse cx='31' cy='75' rx='12' ry='5' fill='rgba(255,255,255,.62)'/>" },
    football: { a: "#4ce083", b: "#12c77a", c: "#e5ffef", shapes: "<path d='M22 50 C32 24 68 24 78 50 C68 76 32 76 22 50 Z' fill='rgba(255,255,255,.24)' stroke='white' stroke-width='5'/><path d='M36 50 H64 M44 42 V58 M50 42 V58 M56 42 V58' stroke='white' stroke-width='4'/><path d='M29 35 C43 43 57 43 71 35 M29 65 C43 57 57 57 71 65' stroke='white' stroke-width='3' fill='none'/>" },
    fitness: { a: "#61e591", b: "#18c879", c: "#e9fff2", shapes: "<path d='M24 62 C36 40 52 76 66 34' fill='none' stroke='white' stroke-width='5'/><circle cx='68' cy='30' r='8' fill='rgba(255,255,255,.7)'/><path d='M24 77 H78' stroke='white' stroke-width='5'/>" },
    nightlife: { a: "#2f3f6f", b: "#111827", c: "#32d274", shapes: "<path d='M29 24 H71 L64 51 Q50 62 36 51 Z' fill='rgba(255,255,255,.2)' stroke='white' stroke-width='4'/><path d='M50 59 V78 M37 78 H63' stroke='white' stroke-width='5'/><path d='M28 31 H72 M37 39 H63' stroke='white' stroke-width='4'/><circle cx='72' cy='24' r='8' fill='rgba(255,255,255,.65)'/>" }
  };
  const item = art[key] || art[event.cat] || art.community;
  const svg = `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'><stop stop-color='${item.a}'/><stop offset='.58' stop-color='${item.b}'/><stop offset='1' stop-color='${item.c}'/></linearGradient><pattern id='dots' width='16' height='16' patternUnits='userSpaceOnUse'><circle cx='3' cy='3' r='2' fill='rgba(255,255,255,.18)'/></pattern></defs><rect width='100' height='100' rx='18' fill='url(#g)'/><rect width='100' height='100' rx='18' fill='url(#dots)'/><circle cx='80' cy='18' r='18' fill='rgba(255,255,255,.14)'/><circle cx='18' cy='82' r='25' fill='rgba(255,255,255,.12)'/>${item.shapes}</svg>`;
  return `url('data:image/svg+xml,${encodeURIComponent(svg)}')`;
}

function eventArtScene(event) {
  if (event.image) return "";
  const scenes = {
    concerts: "<svg viewBox='0 0 100 100' aria-hidden='true'><path d='M24 72 C38 47 62 47 76 72' fill='none'/><path d='M38 48 V24 L66 32 V58'/><circle cx='38' cy='70' r='9'/><circle cx='66' cy='70' r='9'/></svg>",
    "performing-arts": "<svg viewBox='0 0 100 100' aria-hidden='true'><path d='M20 26 Q50 14 80 26 L72 76 Q50 64 28 76 Z'/><circle cx='39' cy='41' r='4'/><circle cx='61' cy='41' r='4'/><path d='M38 58 Q50 68 62 58' fill='none'/></svg>",
    sports: "<svg viewBox='0 0 100 100' aria-hidden='true'><circle cx='50' cy='50' r='31' fill='none'/><path d='M20 50 H80 M50 19 C37 36 37 64 50 81 M50 19 C63 36 63 64 50 81' fill='none'/></svg>",
    festivals: "<svg viewBox='0 0 100 100' aria-hidden='true'><path d='M18 40 C34 23 66 23 82 40' fill='none'/><path d='M26 47 H74 L68 78 H32 Z'/><path d='M38 47 V78 M50 36 V78 M62 47 V78' fill='none'/></svg>",
    community: "<svg viewBox='0 0 100 100' aria-hidden='true'><path d='M23 80 V38 H47 V80 M53 80 V25 H77 V80'/><path d='M31 49 H40 M61 37 H70 M61 51 H70' fill='none'/></svg>",
    expos: "<svg viewBox='0 0 100 100' aria-hidden='true'><rect x='20' y='25' width='60' height='52' rx='7'/><path d='M31 40 H69 M31 53 H69 M31 66 H56' fill='none'/></svg>",
    food: "<svg viewBox='0 0 100 100' aria-hidden='true'><path d='M30 23 V58 M40 23 V58 M30 41 H40 M61 23 V78' fill='none'/><path d='M22 71 C34 55 66 55 78 71'/><circle cx='50' cy='49' r='10'/></svg>",
    film: "<svg viewBox='0 0 100 100' aria-hidden='true'><rect x='19' y='29' width='62' height='42' rx='7'/><path d='M38 40 L38 60 L60 50 Z'/><path d='M25 36 H30 M25 48 H30 M25 60 H30 M70 36 H75 M70 48 H75 M70 60 H75' fill='none'/></svg>",
    museum: "<svg viewBox='0 0 100 100' aria-hidden='true'><path d='M18 78 H82'/><path d='M24 35 H76 L50 19 Z'/><path d='M29 35 V72 M43 35 V72 M57 35 V72 M71 35 V72'/><path d='M23 72 H77'/></svg>",
    arts: "<svg viewBox='0 0 100 100' aria-hidden='true'><rect x='24' y='21' width='52' height='60' rx='8'/><circle cx='42' cy='43' r='10'/><path d='M31 68 C42 55 54 62 68 42' fill='none'/></svg>",
    comedy: "<svg viewBox='0 0 100 100' aria-hidden='true'><path d='M25 28 Q50 18 75 28 L70 72 Q50 84 30 72 Z'/><circle cx='40' cy='43' r='4'/><circle cx='60' cy='43' r='4'/><path d='M38 59 Q50 68 62 59' fill='none'/></svg>",
    run: "<svg viewBox='0 0 100 100' aria-hidden='true'><path d='M24 68 C34 77 55 78 77 66 C81 64 80 57 75 56 L58 52 L45 37 L36 42 L46 58 L31 57 C24 56 20 63 24 68 Z'/><path d='M31 70 C42 74 58 74 75 66 M45 58 L58 52' fill='none'/><circle cx='38' cy='33' r='7'/></svg>",
    baseball: "<svg viewBox='0 0 100 100' aria-hidden='true'><circle cx='50' cy='50' r='31'/><path d='M33 26 C41 38 41 62 33 74 M67 26 C59 38 59 62 67 74' fill='none'/><path d='M36 37 L41 34 M36 47 L42 45 M36 57 L42 60 M64 37 L59 34 M64 47 L58 45 M64 57 L58 60'/></svg>",
    basketball: "<svg viewBox='0 0 100 100' aria-hidden='true'><circle cx='50' cy='50' r='31'/><path d='M20 50 H80 M50 19 V81 M29 29 C43 41 43 59 29 71 M71 29 C57 41 57 59 71 71' fill='none'/></svg>",
    soccer: "<svg viewBox='0 0 100 100' aria-hidden='true'><circle cx='50' cy='50' r='31'/><path d='M50 34 L64 44 L59 61 H41 L36 44 Z'/><path d='M50 34 V22 M64 44 L78 39 M59 61 L66 75 M41 61 L34 75 M36 44 L22 39' fill='none'/></svg>",
    hockey: "<svg viewBox='0 0 100 100' aria-hidden='true'><path d='M34 21 L51 68 M66 21 L52 68 M42 70 H71' fill='none'/><ellipse cx='31' cy='75' rx='12' ry='5'/></svg>",
    football: "<svg viewBox='0 0 100 100' aria-hidden='true'><path d='M22 50 C32 24 68 24 78 50 C68 76 32 76 22 50 Z'/><path d='M36 50 H64 M44 42 V58 M50 42 V58 M56 42 V58' fill='none'/><path d='M29 35 C43 43 57 43 71 35 M29 65 C43 57 57 57 71 65' fill='none'/></svg>",
    fitness: "<svg viewBox='0 0 100 100' aria-hidden='true'><path d='M24 63 C36 41 52 76 66 34' fill='none'/><circle cx='68' cy='30' r='8'/><path d='M24 78 H78' fill='none'/></svg>",
    nightlife: "<svg viewBox='0 0 100 100' aria-hidden='true'><path d='M29 24 H71 L64 51 Q50 62 36 51 Z'/><path d='M50 59 V78 M37 78 H63' fill='none'/><path d='M28 31 H72 M37 39 H63' fill='none'/><circle cx='72' cy='24' r='8'/></svg>"
  };
  return `<span class="art-scene art-scene-${eventArtKind(event)}">${scenes[eventArtKind(event)] || scenes.community}</span>`;
}

function eventArtImage(event) {
  if (event.image) return `url('${String(event.image).replace(/'/g, "%27")}')`;
  return genericEventArt(event);
}

function seededPerformingArtsFallbackTags(seedText) {
  const pool = ["Curtain Call", "Limited Run", "Tour Stop", "Ensemble", "Solo Set", "Matinee", "Late Show", "New Work", "Classic Story", "Reserved Seating"];
  const seed = Array.from(String(seedText || "lokal")).reduce((total, char) => total + char.charCodeAt(0), 0);
  return [pool[seed % pool.length], pool[(seed + 4) % pool.length]];
}

function seededConcertFallbackTags(seedText) {
  const pool = ["Tour Stop", "Club Show", "New Release", "Small Room", "Late Set", "Featured Artist", "Dance Floor", "Local Stage", "Vocal Set", "Deep Cuts"];
  const seed = Array.from(String(seedText || "lokal")).reduce((total, char) => total + char.charCodeAt(0), 0);
  return [pool[seed % pool.length], pool[(seed + 5) % pool.length]];
}

function eventTags(event) {
  const labels = { concerts: "Concerts", "performing-arts": "Arts", museums: "Museums", festivals: "Festivals", sports: "Sports", community: "Community", expos: "Expos", nightlife: "Nightlife" };
  const raw = Array.isArray(event.tags) ? event.tags : [event.tag, event.cat];
  const tags = raw
    .map(tag => typeof tag === "object" && tag !== null ? (tag.label || tag.name || tag.title || tag.value || "") : tag)
    .map(tag => String(tag || "").trim())
    .map(tag => labels[tag.toLowerCase()] || tag)
    .filter(tag => tag && tag !== "[object Object]")
    .filter((tag, index, all) => all.findIndex(item => item.toLowerCase() === tag.toLowerCase()) === index);
  if (String(event.cat || "").toLowerCase() === "concerts") {
    const text = `${event.title || ""} ${event.venue || ""} ${event.desc || ""} ${event.tag || ""} ${raw.join(" ")}`.toLowerCase();
    const inferred = [];
    const add = (label, pattern) => { if (pattern.test(text) && !inferred.includes(label)) inferred.push(label); };
    add("Hip-Hop", /\b(hip[- ]?hop|rap|rapper|conway|chris travis)\b/);
    add("R&B", /r&b|rhythm and blues|jill scott|bayou/);
    add("Jazz", /jazz|bebop|swing/);
    add("Go-Go", /go[- ]?go|northeast groovers|wpgc/);
    add("Pop", /\bpop\b|dorian electra|fulton lee|flawed mangoes|daniela andrade/);
    add("Rock", /music - rock|\brock band\b|\balt[- ]rock\b|\bindie rock\b|the church|the kills|of montreal/);
    add("Indie", /indie|alt[- ]|alternative|of montreal|son little|bixby|flawed mangoes/);
    add("Folk", /folk|americana|singer[- ]songwriter|josiah and the bonnevilles|orville peck/);
    add("Country", /music - country|country music|orville peck|kolby cooper/);
    add("Electronic", /electronic|edm|dance music|dj set|rufus|rüfüs|echostage|soundcheck/);
    add("Latin", /latin|reggaeton|salsa|bachata|cumbia|paco amoroso|ca7riel/);
    add("Soul", /soul|funk|big freedia|tank and the bangas/);
    add("DJ Set", /\bdj\b|deejay|turntable|vinyl/);
    add("Album Tour", /album|record release|new release|listening session|playlist/);
    add("Tour Stop", /\btour\b|world tour|north america/);
    add("Local Artist", /dc artist|local artist|local lineup|hometown/);
    add("Free", /free admission|free event|free concert|free show|rsvp free|no cover/);
    add("18+", /\b18\+\b|ages 18/);
    add("21+", /\b21\+\b|ages 21/);
    add("Club Show", /9:30 club|930 club|the atlantis|union stage|black cat|dc9|songbyrd/);
    add("Big Room", /the anthem|echostage|arena|stadium|audi field/);
    const clean = tags.filter(tag => !["concert", "concerts", "live music", "music", "arts", "art", "free"].includes(tag.toLowerCase()));
    const fallback = seededConcertFallbackTags(`${event.title || ""} ${event.venue || ""}`).filter(() => clean.length + inferred.length < 2);
    return [...clean, ...inferred, ...fallback]
      .filter((tag, index, all) => tag && all.findIndex(item => item.toLowerCase() === tag.toLowerCase()) === index)
      .slice(0, Math.max(3, clean.length + inferred.length + fallback.length));
  }
  if (String(event.cat || "").toLowerCase() !== "performing-arts") return tags;
  const text = `${event.title || ""} ${event.venue || ""} ${event.desc || ""} ${event.tag || ""} ${raw.join(" ")}`.toLowerCase();
  const inferred = [];
  const add = (label, pattern) => { if (pattern.test(text) && !inferred.includes(label)) inferred.push(label); };
  add("Comedy", /comedy|stand[- ]?up|improv|comic|open mic/);
  add("Broadway", /broadway|moulin rouge|suffs|lion king|wicked|hamilton/);
  add("Play", /\b(play|drama)\b|othello|hamlet|macbeth/);
  add("Musical", /musical|moulin rouge|suffs|wicked|hamilton|lion king/);
  add("Opera", /\bopera\b(?! house)/);
  add("Touring Production", /touring|\btour\b/);
  add("Family Friendly", /family|kids|children|bluey|disney/);
  add("Dance", /dance|ballet|choreo/);
  add("Film", /film|cinema|screening|movie/);
  add("Gallery", /gallery|exhibit|exhibition|installation|visual art/);
  add("Classical", /symphony|orchestra|classical|chamber music/);
  add("Cabaret", /cabaret/);
  add("Drag", /\bdrag\b|drag queen|drag brunch/);
  add("Magic", /magic|illusionist/);
  add("Storytelling", /storytelling|story slam|moth/);
  add("Spoken Word", /spoken word|poetry/);
  const clean = tags.filter(tag => !["arts", "art", "performing-arts", "performing arts", "museum", "museums", "smithsonian", "performance", "theater", "theatre", "stage show", "touring show", "family show", "live show", "ticketed", "opera"].includes(tag.toLowerCase()));
  const fallback = seededPerformingArtsFallbackTags(`${event.title || ""} ${event.venue || ""}`).filter(tag => clean.length + inferred.length < 2 || inferred.length < 2);
  return [...clean, ...inferred, ...fallback]
    .filter((tag, index, all) => tag && all.findIndex(item => item.toLowerCase() === tag.toLowerCase()) === index)
    .slice(0, Math.max(3, clean.length + inferred.length + fallback.length));
}

function eventTagChips(event, limit = 3) {
  return eventTags(event).slice(0, limit).map(tag => `<span class="event-tag">${escapeHtml(tag)}</span>`).join("");
}

function primaryEventTag(event) {
  return eventTags(event)[0] || event.tag || event.cat || "Local event";
}

function eventArtLabel(event) {
  const category = String(event.cat || event.category || "").toLowerCase();
  const labels = {
    music: "Concert",
    concerts: "Concert",
    art: "Arts",
    "performing-arts": "Arts",
    museums: "Museums",
    theatre: "Arts",
    theater: "Arts",
    sports: "Sports",
    fitness: "Fitness",
    food: "Food",
    festivals: "Festival",
    community: "Community",
    expos: "Expo",
    nightlife: "Night out"
  };
  if (labels[category]) return labels[category];
  const tagText = eventTags(event).join(" ").toLowerCase();
  const text = `${event.cat || ""} ${event.category || ""} ${event.tag || ""} ${tagText} ${event.title || ""}`.toLowerCase();
  if (/\b(nightlife|nightclub|club|bar|lounge|rooftop|cocktail|dance party|after dark|late night)\b/.test(text)) return "Night out";
  if (/\b(concert|music|pop|rock|jazz|classical|dj|band|singer|songwriter|vinyl)\b/.test(text)) return "Concert";
  if (/\b(museum|smithsonian|hirshhorn|renwick|portrait gallery|american art museum|air and space|natural history|american history)\b/.test(text)) return "Museums";
  if (/\b(theatre|theater|performing|arts?|gallery|comedy|film|cinema)\b/.test(text)) return "Arts";
  if (/\b(baseball|mlb|nba|nfl|nhl|soccer|sports?|game)\b/.test(text)) return "Sports";
  if (/\b(food|drink|wine|beer|cocktail|restaurant|brunch|market)\b/.test(text)) return "Food";
  if (/\b(festival|fair)\b/.test(text)) return "Festival";
  if (/\b(expo|conference|convention)\b/.test(text)) return "Expo";
  if (/\b(run|yoga|fitness|wellness|pickleball)\b/.test(text)) return "Fitness";
  if (/\b(community|volunteer|neighborhood|meetup)\b/.test(text)) return "Community";
  return "Community";
}

function eventRow(event) {
  const signal = eventInterestSignal(event);
  const label = event.id === 5 ? "Featured partner" : event.id === 7 ? "Curated by @dcafterdark" : event.id === 8 ? "Popular near you" : "Trending";
  const attachedGroup = event.id === 3 ? `<div class="signal">Hosted by public group: DC Run Club</div>` : event.id === 4 ? `<div class="signal">Join the Skyline Social event chat</div>` : "";
  const image = eventArtImage(event);
  const tags = eventTags(event);
  return `<button class="event-row feed-event" data-event="${event.id}" data-search-text="${`${event.title} ${event.venue} ${event.area} ${event.cat} ${tags.join(" ")}`.toLowerCase()}">
    <span class="event-art cat-${eventVisualCategory(event)}" style="background-image: linear-gradient(180deg, rgba(17,24,39,.06), rgba(17,24,39,.34)), ${image};">${eventArtScene(event)}<span class="art-label">${escapeHtml(eventArtLabel(event))}</span></span>
    <span class="event-copy"><span class="feed-label">${label}</span><span class="event-meta">${event.time} / ${event.price}</span><h3>${event.title}</h3><p>${event.venue} / ${event.area}</p><span class="event-tags">${eventTagChips(event)}</span>${signal}${attachedGroup}</span>
  </button>`;
}

function isHighlighted(event) { return [4, 5].includes(event.id); }

function eventNumericPrice(event) {
  if (event.price === "Free") return 0;
  const match = String(event.price || "").match(/\$?(\d+(?:\.\d+)?)/);
  return match ? Number(match[1]) : null;
}

function eventStartHour(event) {
  if (event.startHour !== undefined && event.startHour !== null) return event.startHour;
  const match = String(event.time || "").match(/(\d{1,2})(?::\d{2})?\s*(AM|PM)/i);
  if (!match) return null;
  let hour = Number(match[1]) % 12;
  if (match[2].toUpperCase() === "PM") hour += 12;
  return hour;
}

function eventStartSortValue(event) {
  if (Number.isFinite(event.startSort)) return event.startSort;
  if (event.startSort === Number.POSITIVE_INFINITY) return Number.MAX_SAFE_INTEGER;
  const timeText = String(event.time || "");
  const dayOrder = timeText.startsWith("Tonight") ? 0
    : timeText.startsWith("Today") ? 0
      : timeText.startsWith("Fri") ? 1
        : timeText.startsWith("Sat") ? 2
          : timeText.startsWith("Sun") ? 3
            : 99;
  const hour = eventStartHour(event);
  return dayOrder * 24 * 60 * 60 * 1000 + (hour ?? 24) * 60 * 60 * 1000;
}

function eventDateValue(event) {
  if (event.startDate) {
    const date = new Date(`${event.startDate}T00:00:00`);
    if (!Number.isNaN(date.getTime())) return date;
  }
  if (Number.isFinite(event.startSort) && event.startSort < Number.MAX_SAFE_INTEGER) {
    const date = new Date(event.startSort);
    date.setHours(0, 0, 0, 0);
    return date;
  }
  return null;
}

function sameCalendarDate(a, b) {
  return a && b && a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
}

function matchesDateFilter(event, value) {
  if (!value || value === "Any date") return true;
  const eventDate = eventDateValue(event);
  if (!eventDate) return false;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  if (value === "Today") return sameCalendarDate(eventDate, today);
  if (value === "This week") {
    const weekEnd = new Date(today);
    weekEnd.setDate(today.getDate() + 6);
    return eventDate >= today && eventDate <= weekEnd;
  }
  if (value === "This weekend") {
    const saturday = new Date(today);
    saturday.setDate(today.getDate() + ((6 - today.getDay() + 7) % 7));
    const sunday = new Date(saturday);
    sunday.setDate(saturday.getDate() + 1);
    return sameCalendarDate(eventDate, saturday) || sameCalendarDate(eventDate, sunday);
  }
  const range = String(value).match(/^(\d{4}-\d{2}-\d{2})\.\.(\d{4}-\d{2}-\d{2})$/);
  if (range) {
    const start = new Date(`${range[1]}T00:00:00`);
    const end = new Date(`${range[2]}T23:59:59`);
    return eventDate >= start && eventDate <= end;
  }
  if (/^\d{4}-\d{2}-\d{2}$/.test(value)) return event.startDate === value || sameCalendarDate(eventDate, new Date(`${value}T00:00:00`));
  return true;
}

function sortEventsByStart(a, b) {
  const startDelta = eventStartSortValue(a) - eventStartSortValue(b);
  if (startDelta !== 0) return startDelta;
  return String(a.title || "").localeCompare(String(b.title || ""));
}

function matchesTimeFilter(event, value) {
  if (!value || value === "Any time") return true;
  const hour = eventStartHour(event);
  if (hour === null) return false;
  if (value === "Morning") return hour >= 4 && hour < 12;
  if (value === "Afternoon") return hour >= 12 && hour < 16;
  if (value === "Evening") return hour >= 16 && hour < 21;
  if (value === "Late night") return hour >= 21 || hour < 4;
  return true;
}

function matchesFilter(event, filter, applyDiscoverFilters = true) {
  const priceValue = eventNumericPrice(event);
  if (state.age < 21 && event.cat === "nightlife") return false;
  if (applyDiscoverFilters && state.highlightedOnly && !isHighlighted(event)) return false;
  if (applyDiscoverFilters && state.filter.category && state.filter.category !== "All categories" && event.cat !== state.filter.category) return false;
  if (applyDiscoverFilters && !matchesDateFilter(event, state.filter.date)) return false;
  if (applyDiscoverFilters && !matchesTimeFilter(event, state.filter.time)) return false;
  if (applyDiscoverFilters && state.filter.price === "Free" && event.price !== "Free") return false;
  if (applyDiscoverFilters && state.filter.price === "Under $20" && (priceValue === null || priceValue >= 20)) return false;
  if (applyDiscoverFilters && state.filter.price === "Under $50" && (priceValue === null || priceValue >= 50)) return false;
  if (filter === "all" || filter === "for-you") return true;
  if (filter === "nearby") return true;
  if (filter === "weekend") return !event.time.startsWith("Tonight");
  if (filter === "tonight") return event.time.startsWith("Tonight");
  if (filter === "free") return event.price === "Free";
  return event.cat === filter;
}

function discoverFilterItems() {
  return [["all", "All"], ["nearby", "Nearby"], ["concerts", "Concerts"], ["nightlife", "Nightlife"], ["performing-arts", "Performing arts"], ["museums", "Museums"], ["sports", "Sports"], ["festivals", "Festivals"], ["community", "Community"], ["expos", "Expos"], ["free", "Free"]];
}

function filterChips(active, scope) {
  const items = scope === "home"
    ? discoverFilterItems()
    : [["all", "All"], ["concerts", "Concerts"], ["nightlife", "Nightlife"], ["performing-arts", "Arts"], ["museums", "Museums"], ["sports", "Sports"], ["festivals", "Festivals"], ["community", "Community"], ["expos", "Expos"]];
  return items.map(([value, label]) => `<button class="${scope === "home" ? "chip" : "filter-chip"} ${active === value ? "active" : ""}" data-${scope}-filter="${value}">${label}</button>`).join("");
}


